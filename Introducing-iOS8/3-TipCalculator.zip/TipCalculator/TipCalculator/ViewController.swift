//
//  ViewController.swift
//  TipCalculator
//
//  Created by Demo on 9/24/14.
//  Copyright (c) 2014 Demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var billTextField: UITextField!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    
    @IBAction func calculateTapped(sender: AnyObject) {
        var userInput = billTextField.text as NSString
        var totalBill : Float = userInput.floatValue
        
        var index : Int = segmentedControl.selectedSegmentIndex
        var tipRate : Float = 0.15
        
        if index == 0 {
            tipRate = 0.15
        } else if index == 1 {
            tipRate = 0.20
        } else {
            tipRate = 0.25
        }
        
        var tip = totalBill * tipRate
        
        var display = String(format: "$%.2f", tip)
        
        tipLabel.text = display
    }
   
}

