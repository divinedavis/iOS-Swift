// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var isStudent : Bool = true

var firstName : String = "Steve"



var accountBalance = 1024.25

var myFloat : Float = 102.22





var favFood = "Pasta"
favFood.uppercaseString

var beach = "Beach"

beach = beach + "Ball"

beach

let name = "Steve"
var message = "Hello \(name)"

var names : [ String] = ["Steve", "Jeff", "Andy", "Mike"]

names[3]

names.append("Wally")

names

var first = names[0]

first

names.count

names.isEmpty




names


names[2] = "Andy"

names

names.removeAtIndex(3)

names



names.removeLast()




var homeruns = ["Posey" : 30, "Pagan": 10, "Pence" : 25]

var buster = homeruns["Posey"]

homeruns["Sandoval"] = 35

homeruns

homeruns["Posey"] = 40

homeruns

homeruns["Pence"] = nil

homeruns





//LOOPS

var counter = 0

counter < 8

counter++

for (var counter = 0; counter < 8; counter++){
    
    println("steve")
    
}

var favStates = ["California", "New York", "Colorado", "Oregon"]

for state in favStates {
    var message = "\(state) is my favorite state"
}

var a = 1...5

for m in a {
    println(m)
}

var isBirthdayToday = true

if isBirthdayToday == true {
    var message = "Happy Birthday"
}


var isMale = false

if isMale == true {
    var message = "Hello Sir"
} else {
    var message = "Hello Mam"
}


var isWeekday = false
var isSaturday = true

if isWeekday == true {
    var message = "Good Morning"
} else if isSaturday == true {
    var message = "Happy Saturday"
} else {
    var message = "Happy Sunday"
}




var translatedWord : String? = nil


if translatedWord == nil {
var myMessage = "Good Morning"
} else {
var myMessage = translatedWord!
}


//Chap 3

func goodMorning() {
    
    var message = "Good Morning"
    
}

goodMorning()

func goRunning(miles: Int){
    
    var message = "Go for a \(miles) mile run"
}


goRunning(10)


func calculateTax(total: Float) -> Float {

    var tax = total * 0.10
    
    return tax

}

calculateTax(23.40)




class House {

    var exteriorColor = "Brown"
    var currentAirTemp = 70
    var isGarageOpen = true
    var isAlarmEnabled = false
    
    func prepareForNighttime(){
        
        isGarageOpen = false
        isAlarmEnabled = true
        currentAirTemp = 65
        
    }
    


}


var myHouse = House()

myHouse.exteriorColor


myHouse.exteriorColor = "Red"

myHouse.exteriorColor

myHouse.prepareForNighttime()

myHouse



class Cabin : House {
    
    override init(){
        super.init()
        exteriorColor = "Logs"
    }
    
    override func prepareForNighttime(){
       exteriorColor = "BROWNIE"
    }

}




//Chap 4

class HelloViewController : UIViewController {
    
    override func viewDidLoad () {
        super.viewDidLoad()
        
        var message = "Hello World"
    }
    
}


//chp 6

var tip : Float = totalabill * tipRate









