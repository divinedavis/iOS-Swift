//
//  RaceCar.swift
//  RaceCar
//
//  Created by Demo on 9/24/14.
//  Copyright (c) 2014 Demo. All rights reserved.
//

import UIKit

class RaceCar: NSObject {
   
    //color
    var color : String = "Red"

    //top speed
    var topSpeed : Int = 200
    
    //brand
    var brand : String = "Ferrari"
    
    
    func honk(){
        println("Honk! Honk!")
    }
}
