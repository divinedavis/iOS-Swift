//
//  ViewController.swift
//  RaceCar
//
//  Created by Demo on 9/24/14.
//  Copyright (c) 2014 Demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func honkTapped(sender: AnyObject) {
        
        // Create Car
        var myCar = RaceCar()
        
        // Display Car
        brandLabel.text = myCar.brand
        colorLabel.text = myCar.color
        topSpeedLabel.text = "\(myCar.topSpeed)"
        
        // Honk Car
        myCar.honk()
        
    }
    @IBOutlet weak var topSpeedLabel: UILabel!
    @IBOutlet weak var colorLabel: UILabel!
    @IBOutlet weak var brandLabel: UILabel!

}

