//
//  ViewController.swift
//  HelloWorld
//
//  Created by Demo on 9/24/14.
//  Copyright (c) 2014 Demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func goButtonTapped(sender: AnyObject) {
        
        mainLabel.text = "Hello World"
    }
    
    @IBOutlet weak var mainLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

